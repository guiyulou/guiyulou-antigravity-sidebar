# guiyulou-antigravity-sidebar 1.0

**作者**　西塞山的鳜鱼篓

这款侧栏插件把工作区文件放在 Antigravity 桌面应用的右侧，方便边读边讨论。你可以阅读 PDF 和 Markdown、预览 HTML、编辑代码，也可以选中一段原文，写下评论，再把带编号的引用加入当前对话。插件菜单和面板标签显示为「侧边栏」，面板内的操作按钮使用英文。

## 安装

使用 macOS 版 Antigravity 2.22.0 或更新版本。插件优先使用 Antigravity 附带的运行时，也支持系统里的 Node.js 22 或更新版本。Windows 和 Linux 尚未验证。[Antigravity 2.22.0 发布说明](https://antigravity.google/releases?tab=hub&version=2.22.0)

1. 下载并解压 1.0 安装包，找到内含 `plugin.json` 的 `guiyulou-antigravity-sidebar` 文件夹。从 GitHub 的 `Code` 菜单下载源码 ZIP 时，也使用里面的这个文件夹。[下载 guiyulou-antigravity-sidebar 1.0 安装包](./guiyulou-antigravity-sidebar-1.0.zip?raw=1)
2. 在访达按 `⌘⇧G`，输入 `~/.gemini/config/`。打开 `plugins` 文件夹，如果尚不存在就新建一个，再将整个 `guiyulou-antigravity-sidebar` 复制进去。复制后应能找到 `~/.gemini/config/plugins/guiyulou-antigravity-sidebar/plugin.json`。
3. 完全退出并重新打开 Antigravity，登录后打开一个对话。点右侧窗格标签栏末端的 `+`，在「扩展插件」中选择「侧边栏」，也可以直接搜索「侧边栏」。

如果搜不到这个面板，请打开 `~/.gemini/config/config.json`。把下面的 `guiyulou-antigravity-sidebar/doc-pane` 条目加入 `sidecars` 后重启应用。如果已有其他配置，保留原有条目。

```json
{
  "sidecars": {
    "guiyulou-antigravity-sidebar/doc-pane": { "enabled": true }
  }
}
```

更新前请完全退出 Antigravity。要保留已有批注，先备份旧插件文件夹里的 `notes.md` 和 `notes.json`，安装新版后将它们放进 `guiyulou-antigravity-sidebar` 文件夹。如果这款插件的旧文件夹使用其他名称，请先把它移出 `plugins`。如果曾在 `config.json` 中手动启用旧版，请把 `sidecars` 里对应的配置项改名为 `guiyulou-antigravity-sidebar/doc-pane`。

## 阅读和批注

- **打开文件。** 左侧目录树可以浏览工作区，搜索框按文件名查找。最多同时打开 8 个标签页。把标签页或目录树里的文件拖到显示区右半边，就能并排阅读。点工具栏的 `Refresh` 可以重新读取当前文件。
- **阅读或编辑。** PDF 支持缩放和文字批注。Markdown 可在 `Read`、`Live`、`Source` 三种视图之间切换。代码和纯文本可直接编辑，点击 `Save` 会写回原文件。
- **预览 HTML。** 点开 HTML 文件时，预览会立即运行网页自带的脚本，交互图表也能随页面加载。**只在面板中打开自己编写或确认可信的 HTML 文件。** 预览页面和插件面板共享访问权限。来源不明的 HTML 建议先用文本编辑器查看。
- **添加评论。** 在正文中选中文字，点 `Comment`，写下评论，再点 `Add to chat`。文中会出现编号，插件会尝试将类似 `[Ref 1] 请核对单位` 的文字填入对话框。你可以继续编辑，再自行发送。
- **管理批注。** 点正文中的编号可以修改或删除评论。顶栏的 `Notes` 列出本轮批注，可以从列表跳回原文。发送带引用的消息后，新一轮从 1 重新编号。`Clear all` 会清除本轮和过往各轮的全部批注。
- **在面板里查看对话。** 面板最大化后，第一次点 `Chat` 会显示原有对话输入框，再点一次展开聊天记录，第三次点击收起。还可以在展开的聊天记录中选中文字写评论。

## 对话框兼容性

`Add to chat`、文件或文件夹的 `@` 引用，以及面板中的对话控件，依赖 Antigravity 桌面端的调试连接。这个接口可能随应用版本和启动方式变化。如果看到 `Could not insert into the chat box`，可以在 `Notes` 中找到已经保存的批注，按评论编号和开头文字手动填入对话框。

此前的开发版在 macOS 和 Antigravity 2.33.0 上成功安装，桌面应用自动启动了面板。当时云端桌面停在 Google 登录页。开源版 1.0 尚未做运行测试，已登录桌面应用中的自动插入效果也待验证。

## 本机数据

插件后台只监听本机地址。打开和保存文件时，使用当前 macOS 用户的文件权限。HTML 预览中的外部资源由页面自己加载。

完整批注存放在 `~/.gemini/config/plugins/guiyulou-antigravity-sidebar/notes.md` 和 `notes.json`，包括原文选区、评论和文件位置。HTML 批注还会保存对应元素的定位和一小段源码。对话里出现 `[Ref n]` 时，插件附带的规则会指引 Antigravity 读取对应的本机批注。插入操作的调试日志只记录「插入成功」或「插入失败」。

有待发送批注时，插件会定期读取当前对话的本机记录，判断带编号的消息是否已经发出，以便开始新一轮编号。

## 卸载

退出 Antigravity，移除 `~/.gemini/config/plugins/guiyulou-antigravity-sidebar/`。需要保留的批注可以先从这个文件夹复制出来。如果手动添加过 `guiyulou-antigravity-sidebar/doc-pane` 配置，也请移除对应条目。

## 许可证

插件的原创代码和文档采用 MIT 许可证，版权归「西塞山的鳜鱼篓」所有。使用、修改和分发时请保留版权声明和许可文本。[MIT 许可证](LICENSE)

安装包附带 PDF.js、markdown-it 和 CodeMirror。第三方代码沿用各自的许可证，Markdown 浏览器版本内嵌组件的署名也一并保留。[第三方许可证和署名](guiyulou-antigravity-sidebar/LICENSES/)
